package com.example.men_and_okno;

import androidx.appcompat.app.AppCompatActivity;



import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.graphics.Color;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.app.Dialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle("Проверка знаний");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.dialog_layout);
        EditText FIO = (EditText) dialog.findViewById(R.id.FIO_txt);

        Button button =(Button) dialog.findViewById(R.id.Ok_btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });
        Button butt =(Button) dialog.findViewById(R.id.canel_btn);
        butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.setCancelable(false);
        dialog.setTitle("Авторизация");
        dialog.show();


    }
    public boolean onCreateOptionsMenu(Menu menu) {
        setTitle("Проверка знаний");
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int ids = item.getItemId();
        TextView txt1 = (TextView) findViewById(R.id.header);
        TextView txt2 = (TextView) findViewById(R.id.header2);
        TextView txt3 = (TextView) findViewById(R.id.header3);
        TextView txt4 = (TextView) findViewById(R.id.header4);
        TextView txt5 = (TextView) findViewById(R.id.header5);
        EditText otv1 = (EditText) findViewById(R.id.otv1);
        EditText otv2 = (EditText) findViewById(R.id.otv2);
        EditText otv3 = (EditText) findViewById(R.id.otv3);
        EditText otv4 = (EditText) findViewById(R.id.otv4);
        EditText otv5 = (EditText) findViewById(R.id.otv5);
        Button btn =(Button) findViewById(R.id.otv_btn);
        switch (ids){
            case R.id.easy:
                txt1.setText("2*2 =");
                txt2.setText("5*6 =");
                txt3.setText("7*3 =");
                txt4.setText("9*9 =");
                txt5.setText("3*3 =");
                otv1.isEnabled();
                otv2.isEnabled();
                otv3.isEnabled();
                otv4.isEnabled();
                otv5.isEnabled();
                btn.isEnabled();
                return true;
            case R.id.difficult:
                txt1.setText("18*18 =");
                txt2.setText("65*50 =");
                txt3.setText("61*97 =");
                txt4.setText("35*9 =");
                txt5.setText("99*92 =");
                otv1.isEnabled();

                otv2.isEnabled();
                otv3.isEnabled();
                otv4.isEnabled();
                otv5.isEnabled();
                btn.isEnabled();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void ShowDialog (View view)
    {
        final Dialog dialog2 = new Dialog(MainActivity.this);
        dialog2.setContentView(R.layout.dialog_final);
        TextView Final = (TextView) dialog2.findViewById(R.id.final_txt);

        Button fnl_btn = (Button) dialog2.findViewById(R.id.final_btn);
        fnl_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog2.dismiss();
            }

        });
        dialog2.setCancelable(false);
        dialog2.setTitle("Результат");
        dialog2.show();
    }

}
